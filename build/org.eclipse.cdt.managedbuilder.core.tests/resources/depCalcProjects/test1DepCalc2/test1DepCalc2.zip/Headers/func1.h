#ifndef FUNC1_H_
#define FUNC1_H_

#include "func2.h"

int func1(int x);

#endif /*FUNC1_H_*/

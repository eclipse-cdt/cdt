#include "func 3.h"

int func2(int x) {
	x = func3(x);
	return --x;
}

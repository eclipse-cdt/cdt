#ifndef FUNC3_H_
#define FUNC3_H_

int func3(); 

#endif /*FUNC3_H_*/

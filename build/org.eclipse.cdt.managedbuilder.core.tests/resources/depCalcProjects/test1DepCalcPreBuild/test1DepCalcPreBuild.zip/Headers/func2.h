#ifndef FUNC2_H_
#define FUNC2_H_
 
int func2(int x); 

#endif /*FUNC2_H_*/

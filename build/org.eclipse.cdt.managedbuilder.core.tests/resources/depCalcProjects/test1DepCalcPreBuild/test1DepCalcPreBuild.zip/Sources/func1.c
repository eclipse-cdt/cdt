int func1(int x) {
	return ++x;
}

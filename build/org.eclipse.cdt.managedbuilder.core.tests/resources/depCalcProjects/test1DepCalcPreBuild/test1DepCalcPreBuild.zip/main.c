#include "func1.h"
#include "func2.h"

int main(int argc, char **argv) {
	int x = func1(5);
	x = func2(x);
	return x;
}

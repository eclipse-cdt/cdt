/*
 * uobj.c
 *
 *  Created on: 10-Nov-2008
 *      Author: achapiro
 */


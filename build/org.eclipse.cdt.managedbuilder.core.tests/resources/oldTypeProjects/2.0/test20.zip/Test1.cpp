#include "Test1.h"

int main(){
	Test1 *t = new Test1();
	delete t;
	return 0;
}
Test1::Test1()
{}
Test1::~Test1()
{}

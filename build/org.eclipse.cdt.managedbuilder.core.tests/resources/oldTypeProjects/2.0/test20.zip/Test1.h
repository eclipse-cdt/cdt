#ifndef TEST1_H
#define TEST1_H

class Test1{
public:

	Test1();
	virtual ~Test1();
};

#endif // TEST1_H

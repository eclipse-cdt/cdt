int sub1(int x) {
	x = x + 1;
	return x;
}

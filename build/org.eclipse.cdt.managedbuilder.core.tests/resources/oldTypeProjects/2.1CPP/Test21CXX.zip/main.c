extern int sub1(int in);

int main(int argc, char **argv) {
	int ret = sub1(5);
	return ret;
}
#include "Class1.h"

Class1::Class1()
{
}

Class1::~Class1()
{
}

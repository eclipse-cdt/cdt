int so1 (int x) {
	return ++x;
}

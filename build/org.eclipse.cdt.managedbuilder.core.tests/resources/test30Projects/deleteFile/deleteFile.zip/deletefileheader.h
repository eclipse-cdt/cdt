#ifndef _DELETEFILEHEADER_H_
#define _DELETEFILEHEADER_H_

int deletefileheaderint = 4;

#endif /*_DELETEFILEHEADER_H_*/

#include <stdio.h>
#include "deletefileheader.h"

int main(int argc, char **argv) {
	return deletefileheaderint;
}

void a(int a) {
}
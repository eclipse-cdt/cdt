void b(int a) {
}
void d(int a) {
}
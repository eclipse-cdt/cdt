#ifndef _CLASS1_H_
#define _CLASS1_H_

#include "Class2.h"

class Class1
{
public:
	Class1();
	virtual ~Class1();
protected:
	Class2 class2_instance;	
};

#endif /*_CLASS1_H_*/

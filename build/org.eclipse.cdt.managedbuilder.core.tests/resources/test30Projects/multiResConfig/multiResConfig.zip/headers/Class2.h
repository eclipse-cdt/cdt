#ifndef _CLASS2_H_
#define _CLASS2_H_

class Class2
{
public:
	Class2();
	virtual ~Class2();
};

#endif /*_CLASS2_H_*/

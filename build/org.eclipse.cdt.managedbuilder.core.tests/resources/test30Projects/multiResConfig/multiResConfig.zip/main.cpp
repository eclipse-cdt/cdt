#include "Class1.h"

int main(int argc, char **argv) {
	Class1* one = new Class1();
	delete one;
	return 1;
}

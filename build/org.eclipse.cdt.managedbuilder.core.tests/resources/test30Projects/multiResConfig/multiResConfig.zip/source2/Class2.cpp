#include "Class2.h"

Class2::Class2()
{
}

Class2::~Class2()
{
}

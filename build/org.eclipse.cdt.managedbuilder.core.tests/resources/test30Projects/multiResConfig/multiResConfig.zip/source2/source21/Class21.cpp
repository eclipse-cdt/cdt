#include "Class21.h"

Class21::Class21()
{
}

Class21::~Class21()
{
}

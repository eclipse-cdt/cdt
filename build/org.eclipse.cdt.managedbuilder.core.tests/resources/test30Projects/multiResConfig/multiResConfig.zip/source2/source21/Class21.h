#ifndef _CLASS21_H_
#define _CLASS21_H_

class Class21
{
public:
	Class21();
	virtual ~Class21();
};

#endif /*_CLASS21_H_*/

#include <stdio.h>

int main(int argc, char **argv) {
	printf("Hello from rcbsBasicTest.\n");
	return(0);
}

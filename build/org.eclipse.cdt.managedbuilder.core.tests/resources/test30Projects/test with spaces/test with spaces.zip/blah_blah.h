#ifndef BLAH_BLAH_
#define BLAH_BLAH_

#define TheCount

#endif /*BLAH_BLAH_*/

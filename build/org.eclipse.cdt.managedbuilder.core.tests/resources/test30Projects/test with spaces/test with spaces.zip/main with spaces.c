#include <stdio.h>
#include "blah_blah.h"

int main(void)
{
	printf("blah");
	return 0;	
	
}

#include <stdio.h>

int main(void)
{
	printf("blah");
	return 0;	
	
}

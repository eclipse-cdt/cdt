#include <stdio.h>

void foo(void)
{
	printf("foo");
}

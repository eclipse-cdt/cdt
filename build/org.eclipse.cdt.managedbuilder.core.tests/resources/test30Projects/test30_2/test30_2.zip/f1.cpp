#include <stdio.h>
#include "test_so.h"

void f1_so()
{
	printf ( "Hello from f1_so.\n" ) ;
	return ;
}

#include <stdio.h>
#include "test_so.h"

void f2_so()
{
	printf ( "Hello from f2_so.\n" ) ;
	return ;
}

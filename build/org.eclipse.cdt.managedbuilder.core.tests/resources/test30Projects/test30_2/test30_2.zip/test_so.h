void f1_so() ;
void f2_so() ;

#include <stdio.h>

int main(void)
{

	int i = 42;
	int j = 42984298;
	
	printf("i = %d, j = %d\n", i, j);
	
	return 0;	
	
}

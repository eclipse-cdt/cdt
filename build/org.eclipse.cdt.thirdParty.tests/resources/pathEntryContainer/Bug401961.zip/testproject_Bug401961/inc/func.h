extern void func();

#ifdef MAKE
int fucmake;
#endif

void func() {}


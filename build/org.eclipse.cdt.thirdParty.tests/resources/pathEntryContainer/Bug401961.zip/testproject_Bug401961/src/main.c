#include "func.h"
#ifdef CDT_IS_GOOD
int cdt_is_good;
#endif


int main(int argc, char** argv) {
	func();
	return 0;
}

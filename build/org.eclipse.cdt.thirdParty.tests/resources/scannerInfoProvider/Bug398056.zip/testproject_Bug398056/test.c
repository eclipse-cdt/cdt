#ifdef X
int x_is_defined;
#endif

#ifdef Y
int x_is_defined;
#endif

#ifdef Z
int x_is_defined;
#endif

int main(void)
{
	return 0;
}

Files in this directory tree provide CMake support for the CDT core build.

Bundles with a name starting with 'org.eclipse.cdt.cmake.is' provide support for the CDT indexer. 'is' in this case stands for Indexer Support.

#ifndef FOO_H_
#define FOO_H_

void foo(){}


#endif

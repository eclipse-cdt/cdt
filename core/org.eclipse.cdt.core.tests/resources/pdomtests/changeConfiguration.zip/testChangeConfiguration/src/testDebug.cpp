#include "foo.h"

#ifdef DEBUG

int main() {
	foo();
	return 0;
}

#endif

#include "foo.h"

#ifdef RELEASE

int main() {
	foo();
	return 0;
}

#endif

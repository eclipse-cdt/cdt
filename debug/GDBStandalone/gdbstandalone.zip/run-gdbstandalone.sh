#!/bin/sh -x
$HOME/eclipse-cpp-luna-m4/eclipse/eclipse -clean -consoleLog -product GDBStandalone.product -data $HOME/workspace-gdbstandlone -configuration file\:$HOME/gdbstandalone -dev file\:$HOME/gdbstandalone/dev.properties $@ 
# -vmargs -Xrunjdwp:server=y,transport=dt_socket,address=8000,suspend=y

//============================================================================
// Name        : catchpoints.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main() {
	cout << "!!!Hello World!!!" << endl; // prints !!!Hello World!!!

	try {
		int aaa = 2;
		throw 42;
	} catch (int e) {
		cout << e << endl;
	}


	return 0;
}
